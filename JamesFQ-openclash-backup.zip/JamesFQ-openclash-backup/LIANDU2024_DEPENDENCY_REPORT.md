# OpenClash 配置依赖分析与 liandu2024 备份

- 原始配置：`20260930_OpenClash_Gemini_DelayWinthin50 - 副本.yaml`
- 原始配置 SHA-256：`4979e63de46352c7ae694a9fcbba63fb64f815353afd0c20e8a831e35c866fe8`
- 分析时间：2026-10-02T07:47:33

## 结论

配置中直接引用 `liandu2024` 的规则源共 **11** 个。它们通过 `gh-proxy.com` 间接访问 GitHub；代理域名变化或作者仓库删除都会影响更新。

## 直接依赖清单

| 配置中的 URL | 本地快照 | 状态 | SHA-256 |
|---|---|---|---|
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Apple.list` | `liandu2024-clash-list-snapshots/Apple.list` | OK (398 bytes) | `65e945446d55375b939ddb0890cd52273db959e46c4d1f91ae663df2d6fb46d7` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Block.list` | `liandu2024-clash-list-snapshots/Block.list` | OK (99 bytes) | `c5b3a7d21538c7e8f144ae47417209bb43ea1a5cc7d4aafc308982efdc4e4cf3` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Check.list` | `liandu2024-clash-list-snapshots/Check.list` | OK (1757 bytes) | `19c9272be350f34fa3267f9fa048d012147e4689724c7dcda04a127588053b90` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Copilot.list` | `liandu2024-clash-list-snapshots/Copilot.list` | OK (52 bytes) | `e22823b963f6b3de4dafaaf4349537907f4645387afd55a9928d2975db7caf10` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Crunchyroll.list` | `liandu2024-clash-list-snapshots/Crunchyroll.list` | OK (96 bytes) | `e627a06e33126a0ca323137d5e77f106f3c0cc99cca439690062986243ae2bda` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Direct.list` | `liandu2024-clash-list-snapshots/Direct.list` | OK (16101 bytes) | `d4a2204e35b9194e0b4008db38037312276bd54a41245da83be70f4882570f83` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Gemini.list` | `liandu2024-clash-list-snapshots/Gemini.list` | OK (434 bytes) | `6bfeed766db6b5bca138b855d87ed4307aa15e6eece8f8ecc7d9e4fa915eb2ae` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Grok.list` | `liandu2024-clash-list-snapshots/Grok.list` | OK (23 bytes) | `db5045e4dc06747ad516f7a966dfd9090899e9f4201061a8a81bc5c63dacf2bc` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/MetaAi.list` | `liandu2024-clash-list-snapshots/MetaAi.list` | OK (126 bytes) | `89fe8adc674e52a1e553c006ed74985c912a93cef8c2a3669fb2ee4172a0b5a5` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Popcorn.list` | `liandu2024-clash-list-snapshots/Popcorn.list` | OK (27 bytes) | `2c89a2cbe5bbda35663b71e34a4070fc2ceb8f419f33c4c8d3da4747452219e3` |
| `https://gh-proxy.com/raw.githubusercontent.com/liandu2024/clash/refs/heads/main/list/Proxy.list` | `liandu2024-clash-list-snapshots/Proxy.list` | OK (9679 bytes) | `8ba2b0bf760e795b4721a85cab160875691ed15de6b2b69ad4543bad5546d708` |

## 配置中使用这些源的位置

- `TEST / Domain` → `Check.list`，规则 `RULE-SET,TEST / Domain,Test`
- `Meta AI / Domain` → `MetaAi.list`，规则 `RULE-SET,Meta AI / Domain,Meta AI`
- `Copilot / Domain` → `Copilot.list`，规则 `RULE-SET,Copilot / Domain,AI`
- `Gemini / Domain` → `Gemini.list`，规则 `RULE-SET,Gemini / Domain,Gemini`
- `Apple-Custome / Domain` → `Apple.list`，规则 `RULE-SET,Apple-Custome / Domain,Apple`
- `Proxy / Domain` → `Proxy.list`，规则 `RULE-SET,Proxy / Domain,国外`
- `Block / Domain` → `Block.list`，规则 `RULE-SET,Block / Domain,Block`
- `Crunchyroll / Domain` → `Crunchyroll.list`，规则 `RULE-SET,Crunchyroll / Domain,Stream Media`
- `Grok / Domain` → `Grok.list`，规则 `RULE-SET,Grok / Domain,AI`
- `Popcorn / Domain` → `Popcorn.list`，规则 `RULE-SET,Popcorn / Domain,Stream Media`
- `Direct / Domain` → `Direct.list`，规则 `RULE-SET,Direct / Domain,国内`

## 其他外部依赖

配置还引用了 `metacubex/meta-rules-dat`、`blackmatrix7/ios_rule_script`、`MetaCubeX/meta-rules-dat`、`Loyalsoldier/v2ray-rules-dat`、`xishang0128/geoip`、`alecthw/mmdb_china_ip_list` 和 `MetaCubeX/metacubexd`；它们不属于 `liandu2024`，本次未复制。

## 使用建议

备份文件是快照，不会自动更新。若要完全脱离原作者，需把 YAML 中上述 11 个 URL 改为 JamesFQ 仓库的 Raw 地址，并按原文件名保留规则内容；修改前建议保留原始配置。
